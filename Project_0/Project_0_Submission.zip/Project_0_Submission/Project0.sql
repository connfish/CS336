-- locate your DB
--\c cjf192
-- use this if you mess up the upload
--DROP TABLE IF EXISTS Preliminary;

--68 columns
CREATE Table Preliminary(
  as_of_year TEXT,
  respondent_id TEXT,
  agency_name TEXT,
  agency_abbr TEXT,
  agency_code TEXT,
  loan_type_name TEXT,
  loan_type TEXT,
  property_type_name TEXT,
  property_type TEXT,
  loan_purpose_name TEXT,
  loan_purpose TEXT,
  owner_occupancy_name TEXT,
  owner_occupancy TEXT,
  loan_amount_000s TEXT,
  preapproval_name TEXT,
  preapproval TEXT,
  action_taken_name TEXT,
  action_taken TEXT,
  msamd_name TEXT,
  msamd TEXT,
  state_name TEXT,
  state_abbr TEXT,
  state_code TEXT,
  county_name TEXT,
  county_code TEXT,
  census_tract_number TEXT,
  applicant_ethnicity_name TEXT,
  applicant_ethnicity TEXT,
  co_applicant_ethnicity_name TEXT,
  co_applicant_ethnicity TEXT,
  applicant_race_name_1 TEXT,
  applicant_race_1 TEXT,
  applicant_race_name_2 TEXT,
  applicant_race_2 TEXT,
  applicant_race_name_3 TEXT,
  applicant_race_3 TEXT,
  applicant_race_name_4 TEXT,
  applicant_race_4 TEXT,
  applicant_race_name_5 TEXT,
  applicant_race_5 TEXT,
  co_applicant_race_name_1 TEXT,
  co_applicant_race_1 TEXT,
  co_applicant_race_name_2 TEXT,
  co_applicant_race_2 TEXT,
  co_applicant_race_name_3 TEXT,
  co_applicant_race_3 TEXT,
  co_applicant_race_name_4 TEXT,
  co_applicant_race_4 TEXT,
  co_applicant_race_name_5 TEXT,
  co_applicant_race_5 TEXT,
  applicant_sex_name TEXT,
  applicant_sex TEXT,
  co_applicant_sex_name TEXT,
  co_applicant_sex TEXT,
  applicant_income_000s TEXT,
  purchaser_type_name TEXT,
  purchaser_type TEXT,
  denial_reason_name_1 TEXT,
  denial_reason_1 TEXT,
  denial_reason_name_2 TEXT,
  denial_reason_2 TEXT,
  denial_reason_name_3 TEXT,
  denial_reason_3 TEXT,
  rate_spread TEXT,
  hoepa_status_name TEXT,
  hoepa_status TEXT,
  lien_status_name TEXT,
  lien_status TEXT,
  edit_status_name TEXT,
  edit_status TEXT,
  sequence_number TEXT,
  population TEXT,
  minority_population TEXT,
  hud_median_family_income TEXT,
  tract_to_msamd_income TEXT,
  number_of_owner_occupied_units TEXT,
  number_of_1_to_4_family_units TEXT,
  application_date_indicator TEXT
);

--load the CSV from ILAB to DB
\copy Preliminary FROM 'hmda_2017_nj_all-records_labels.csv'
WITH (FORMAT csv, HEADER true, DELIMITER ',', QUOTE '"');

--adding the pkeys
ALTER TABLE Preliminary ADD COLUMN ID BIGSERIAL;
ALTER TABLE Preliminary ADD CONSTRAINT preliminary_pkey PRIMARY KEY (ID);

--check to see if it worked 
SELECT * FROM Preliminary;
-- to show the the DB without looking like giberish use 
--\x on and \x off when done
-- these show the columns as rows with the two columns being csv columns 
--and record data
